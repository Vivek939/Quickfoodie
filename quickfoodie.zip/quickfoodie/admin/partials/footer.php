<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">Quickfoodie. Developed By - <a href="#">Vivek, Sriram, Abubakar</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>